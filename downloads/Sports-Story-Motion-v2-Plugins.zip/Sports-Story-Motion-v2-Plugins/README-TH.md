# ติดตั้ง Sports Story Motion v2

แตก ZIP ทั้งชุด แล้วเปิดโฟลเดอร์ `Sports-Story-Motion-v2-Plugins` ที่มีคู่มือนี้และโฟลเดอร์ `plugins` อยู่ข้างกัน บน Windows ให้คลิกขวาที่พื้นที่ว่างในโฟลเดอร์แล้วเลือก **Open in Terminal** สำหรับคำสั่งด้านล่าง

## Google Antigravity

ใน Antigravity CLI เปิด `/plugin` → **Discover** → **Install from local directory** แล้วเลือกโฟลเดอร์ `plugins/sports-story-motion` ที่มี `plugin.json` อยู่ข้างใน

หรือรันจากโฟลเดอร์ที่มีคู่มือนี้

```text
agy plugin install ./plugins/sports-story-motion
```

ถ้าใช้ Antigravity App บนเดสก์ท็อป คัดลอกโฟลเดอร์ `plugins/sports-story-motion` ไปไว้ใน `.agents/plugins/` ที่รากโปรเจกต์ แล้วเปิดโปรเจกต์นั้น ดูปลั๊กอินใน **Customizations → Installed**

## Codex

รันสองคำสั่งนี้จากโฟลเดอร์ที่มีคู่มือนี้

```text
codex plugin marketplace add .
codex plugin add sports-story-motion@sports-story-motion-local
```

เปิด `/plugins` ใน Codex CLI เพื่อดูปลั๊กอินที่ติดตั้งแล้ว หรือเปิด Codex ใหม่แล้วหา **Sports Story Motion v2** ในเมนู Plugins เก็บโฟลเดอร์ที่แตกไว้ตามเดิมเพื่อให้ Codex เข้าถึงแหล่งติดตั้งได้

## เริ่มใช้งาน

ใน Codex พิมพ์ `$sports-story-motion:sports-story-motion` หรือเปิด `/skills` แล้วเลือกสกิลจากปลั๊กอิน Sports Story Motion v2 ใน Antigravity ให้ระบุชื่อ Sports Story Motion v2 ในข้อความ

ลองสั่งว่า “ใช้ Sports Story Motion v2 วางสตอรีบอร์ดคลิปแนวตั้ง 60 วินาทีเรื่องประวัติสนามฟุตบอล พร้อมคิวแผนที่ บทพากย์ไทย และจังหวะซับ”

สำหรับเรนเดอร์ MP4 ให้ติดตั้ง Python 3.10 ขึ้นไป, Pillow ตาม `requirements.txt` และ FFmpeg ที่รองรับ H.264 ไฟล์คู่มือเรนเดอร์และตัวอย่างเดิมอยู่ใน `plugins/sports-story-motion/skills/sports-story-motion/`

การติดตั้งผ่าน Plugins ใช้โฟลเดอร์ที่แตกออกมาใน Antigravity หรือใช้ Marketplace จากโฟลเดอร์ที่แตกออกมาใน Codex

[เอกสาร Antigravity](https://antigravity.google/docs/plugins)
[เอกสาร Codex](https://learn.chatgpt.com/docs/cli/reference)
